<?php
/**
 * Plugin Name: Payesv WooCommerce Gateway (Debug Build)
 * Description: Accept BDT & USD via Payesv. Initiates payment link and updates order on success/failed. Includes REST webhook verification + extra logging and flexible response parsing.
 * Version:     1.1.2
 * Author:      Payesv
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 9.0
 */

if ( ! defined('ABSPATH') ) exit;

add_action('plugins_loaded', function () {
    if ( ! class_exists('WC_Payment_Gateway') ) return;

    class WC_Gateway_Payesv extends WC_Payment_Gateway {
        const API_ENDPOINT = 'https://www.payesv.com/api/initiate-payment';

        /** @var WC_Logger */
        private $logger;

        public function __construct() {
            $this->id                 = 'payesv';
            $this->method_title       = __('Payesv', 'payesv');
            $this->method_description = __('Pay via Payesv payment link (BDT/USD). Includes webhook verification.', 'payesv');
            $this->has_fields         = false;
            $this->supports           = ['products'];

            $this->init_form_fields();
            $this->init_settings();

            $this->title        = $this->get_option('title', 'Payesv');
            $this->description  = $this->get_option('description', 'Secure payment via Payesv.');
            $this->enabled      = $this->get_option('enabled', 'no');
            $this->api_key      = trim($this->get_option('api_key'));
            $this->brand_key    = trim($this->get_option('brand_key'));
            $this->api_secret   = trim($this->get_option('api_secret'));
            $this->webhook_on   = $this->get_option('webhook_on') === 'yes';

            $this->logger = wc_get_logger();

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
            add_action('woocommerce_api_' . strtolower('wc_gateway_payesv'), [$this, 'handle_return']);

            add_action('rest_api_init', function () {
                register_rest_route('payesv/v1', '/webhook', [
                    'methods'             => 'POST',
                    'callback'            => [$this, 'handle_webhook'],
                    'permission_callback' => '__return_true',
                ]);
            });
        }

        public function init_form_fields() {
            $webhook_url = home_url('/wp-json/payesv/v1/webhook');

            $this->form_fields = [
                'enabled' => [
                    'title'   => __('Enable/Disable', 'payesv'),
                    'type'    => 'checkbox',
                    'label'   => __('Enable Payesv Gateway', 'payesv'),
                    'default' => 'no'
                ],
                'title' => [
                    'title'       => __('Title', 'payesv'),
                    'type'        => 'text',
                    'description' => __('Title shown at checkout.', 'payesv'),
                    'default'     => 'Payesv',
                    'desc_tip'    => true
                ],
                'description' => [
                    'title'       => __('Description', 'payesv'),
                    'type'        => 'textarea',
                    'description' => __('Message shown at checkout.', 'payesv'),
                    'default'     => 'You will be redirected to Payesv to complete the payment securely.'
                ],
                'api_key' => [
                    'title'       => __('x-api-key', 'payesv'),
                    'type'        => 'text',
                    'description' => __('Provided by Payesv.', 'payesv'),
                    'default'     => ''
                ],
                'brand_key' => [
                    'title'       => __('x-brand-key', 'payesv'),
                    'type'        => 'text',
                    'description' => __('Provided by Payesv.', 'payesv'),
                    'default'     => ''
                ],
                'api_secret' => [
                    'title'       => __('x-api-secret', 'payesv'),
                    'type'        => 'password',
                    'description' => __('Used for API calls and webhook signature verification.', 'payesv'),
                    'default'     => ''
                ],
                'webhook_on' => [
                    'title'       => __('Enable Webhook Verification', 'payesv'),
                    'type'        => 'checkbox',
                    'label'       => __('Mark orders paid/failed via server-to-server webhook', 'payesv'),
                    'default'     => 'yes',
                ],
                'webhook_url' => [
                    'title'       => __('Webhook URL (read-only)', 'payesv'),
                    'type'        => 'title',
                    'description' => sprintf(
                        __('Provide this URL to Payesv: <code>%s</code><br/>Signature header: <code>x-signature</code> (HMAC-SHA256 of raw body with your x-api-secret).', 'payesv'),
                        esc_html($webhook_url)
                    ),
                ],
            ];
        }

        public function admin_options() {
            echo '<h2>' . esc_html($this->get_method_title()) . '</h2>';
            echo wpautop(esc_html($this->get_method_description()));
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        }

        public function process_payment($order_id) {
            $order = wc_get_order($order_id);

            $currency = strtoupper( $order->get_currency() );
            if ( ! in_array($currency, ['BDT','USD'], true) ) {
                wc_add_notice(__('Payesv only supports BDT or USD. Please switch the order currency.', 'payesv'), 'error');
                return;
            }

            $amount   = (string) wc_format_decimal( $order->get_total(), 2 );
            $name     = trim($order->get_formatted_billing_full_name());
            $email    = $order->get_billing_email();
            $phone    = $order->get_billing_phone();
            $order_number = $order->get_order_number();

            $base_return = add_query_arg([
                'wc-api'   => 'wc_gateway_payesv',
                'order_no' => rawurlencode($order_number),
                'oid'      => $order->get_id(),
            ], home_url('/'));

            $success_url = add_query_arg('result', 'success', $base_return);
            $failed_url  = add_query_arg('result', 'failed',  $base_return);

            $body = [
                'amount'   => $amount,
                'currency' => $currency,
                'customer' => [
                    'name'  => $name ?: 'Customer',
                    'email' => $email ?: 'no-reply@example.com',
                    'phone' => $phone ?: 'N/A',
                ],
                'orderId'     => (string) $order_number,
                'redirectUrl' => [
                    'success' => $success_url,
                    'failed'  => $failed_url,
                ],
            ];

            // Log request (no secrets)
            $this->log('initiate-request', [
                'order'    => $order_number,
                'amount'   => $amount,
                'currency' => $currency,
                'to'       => self::API_ENDPOINT,
                'body'     => $body,
            ]);

            $response = wp_remote_post( self::API_ENDPOINT, [
                'timeout' => 45,
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'x-api-key'     => $this->api_key,
                    'x-brand-key'   => $this->brand_key,
                    'x-api-secret'  => $this->api_secret,
                ],
                'body'    => wp_json_encode($body),
            ]);

            if ( is_wp_error($response) ) {
                wc_add_notice(__('Payment initialization failed. Please try again.', 'payesv'), 'error');
                $this->log('initiate-error', ['error' => $response->get_error_message(), 'order' => $order_number]);
                return;
            }

            $code = wp_remote_retrieve_response_code($response);
            $raw  = wp_remote_retrieve_body($response);
            $json = json_decode( $raw, true );

            // Log exact response
            $this->log('initiate-response', ['code' => $code, 'raw' => $raw, 'parsed' => $json, 'order' => $order_number]);

            // Accept 'redirectGatewayUrl' and other variants
            $payment_url = null;
            if (is_array($json)) {
                $payment_url = $json['paymentUrl']
                    ?? $json['payment_url']
                    ?? $json['paymentURL']
                    ?? $json['url']
                    ?? $json['link']
                    ?? $json['redirectGatewayUrl']
                    ?? ($json['data']['paymentUrl'] ?? null)
                    ?? ($json['data']['url'] ?? null)
                    ?? ($json['data']['link'] ?? null)
                    ?? ($json['result']['paymentUrl'] ?? null);
            }

            if ( $code !== 200 || empty($payment_url) ) {
                $message = __('Could not get payment link from Payesv. Please try again.', 'payesv');
                if ($code && isset($json['message'])) {
                    $message .= ' [' . esc_html($json['message']) . ']';
                } elseif ($code && $raw && !is_array($json)) {
                    $message .= ' [Invalid JSON returned]';
                }
                wc_add_notice($message, 'error');
                $this->log('initiate-bad-response', ['code' => $code, 'raw' => $raw, 'order' => $order_number]);
                return;
            }

            $order->update_status('pending', __('Awaiting Payesv payment', 'payesv'));
            return [
                'result'   => 'success',
                'redirect' => esc_url_raw( $payment_url ),
            ];
        }

        public function handle_return() {
            $result    = isset($_GET['result'])   ? sanitize_text_field($_GET['result'])   : '';
            $order_no  = isset($_GET['order_no']) ? sanitize_text_field($_GET['order_no']) : '';
            $oid       = isset($_GET['oid'])      ? absint($_GET['oid'])                   : 0;

            if ( empty($order_no) ) wp_die(__('Missing order reference.', 'payesv'));

            $order = $oid ? wc_get_order($oid) : $this->get_order_by_number($order_no);
            if ( ! $order ) wp_die(__('Order not found.', 'payesv'));

            if ( $result === 'success' ) {
                if ( $order->has_status(['pending','on-hold']) ) {
                    $order->payment_complete();
                    $order->add_order_note(__('Payment confirmed via Payesv (return URL).', 'payesv'));
                }
                wc_reduce_stock_levels($order->get_id());
                WC()->cart && WC()->cart->empty_cart();
                wp_safe_redirect( $this->get_return_url($order) );
                exit;
            }

            if ( ! $order->has_status('failed') ) {
                $order->update_status('failed', __('Payment failed via Payesv (return URL).', 'payesv'));
            }
            wc_add_notice(__('Payment failed or cancelled.', 'payesv'), 'error');
            wp_safe_redirect( wc_get_checkout_url() );
            exit;
        }

        public function handle_webhook(\WP_REST_Request $request) {
            if ( ! $this->webhook_on ) {
                return new \WP_REST_Response(['message' => 'Webhook disabled'], 403);
            }

            $raw  = $request->get_body();
            $sig  = $request->get_header('x-signature');
            $calc = hash_hmac('sha256', $raw, (string)$this->api_secret);

            if ( empty($sig) || ! hash_equals($calc, $sig) ) {
                $this->log('webhook-signature-failed', ['provided' => $sig, 'calculated' => $calc]);
                return new \WP_REST_Response(['message' => 'Invalid signature'], 401);
            }

            $data = json_decode($raw, true);
            if ( ! is_array($data) ) {
                $this->log('webhook-invalid-json', ['raw' => $raw]);
                return new \WP_REST_Response(['message' => 'Invalid JSON'], 400);
            }

            $order_no = isset($data['orderId']) ? (string)$data['orderId'] : '';
            $status   = isset($data['status'])  ? strtolower((string)$data['status']) : '';
            $txnId    = isset($data['txnId'])   ? (string)$data['txnId'] : '';
            $amount   = isset($data['amount'])  ? (string)$data['amount'] : '';
            $currency = isset($data['currency'])? strtoupper((string)$data['currency']) : '';

            if ( empty($order_no) || empty($status) ) {
                $this->log('webhook-missing-fields', compact('order_no','status','txnId'));
                return new \WP_REST_Response(['message' => 'Missing fields'], 422);
            }

            $order = $this->get_order_by_number($order_no);
            if ( ! $order ) {
                $this->log('webhook-order-not-found', compact('order_no'));
                return new \WP_REST_Response(['message' => 'Order not found'], 404);
            }

            $last_status = $order->get_meta('_payesv_last_status');
            if ( $last_status === $status ) {
                return new \WP_REST_Response(['message' => 'Already processed'], 200);
            }

            $order_total    = (string) wc_format_decimal($order->get_total(), 2);
            $order_currency = strtoupper($order->get_currency());

            if ( $amount && $order_total !== $amount ) {
                $this->log('webhook-amount-mismatch', ['expected' => $order_total, 'got' => $amount, 'order' => $order_no]);
            }
            if ( $currency && $order_currency !== $currency ) {
                $this->log('webhook-currency-mismatch', ['expected' => $order_currency, 'got' => $currency, 'order' => $order_no]);
            }

            if ( $status === 'success' ) {
                if ( $order->has_status(['pending','on-hold']) ) {
                    $order->payment_complete($txnId ?: '');
                    $order->add_order_note(sprintf(__('Payesv webhook success. TXN: %s', 'payesv'), $txnId ?: 'n/a'));
                    wc_reduce_stock_levels($order->get_id());
                }
                $order->update_meta_data('_payesv_last_status', 'success');
                $order->save();
                return new \WP_REST_Response(['message' => 'Order marked paid'], 200);
            }

            if ( $status === 'failed' ) {
                if ( ! $order->has_status('failed') ) {
                    $order->update_status('failed', sprintf(__('Payesv webhook failed. TXN: %s', 'payesv'), $txnId ?: 'n/a'));
                }
                $order->update_meta_data('_payesv_last_status', 'failed');
                $order->save();
                return new \WP_REST_Response(['message' => 'Order marked failed'], 200);
            }

            $this->log('webhook-unknown-status', compact('status','order_no'));
            return new \WP_REST_Response(['message' => 'Unknown status'], 422);
        }

        private function get_order_by_number($order_number) {
            $query = new WP_Query([
                'post_type'      => 'shop_order',
                'posts_per_page' => 1,
                'post_status'    => array_keys( wc_get_order_statuses() ),
                'meta_query'     => [
                    'relation' => 'OR',
                    [
                        'key'     => '_order_number',
                        'value'   => $order_number,
                        'compare' => '='
                    ],
                    [
                        'key'     => '_order_number_formatted',
                        'value'   => $order_number,
                        'compare' => '='
                    ],
                ]
            ]);
            if ( $query->have_posts() ) {
                return wc_get_order( $query->posts[0]->ID );
            }
            $maybe_id = absint($order_number);
            if ( $maybe_id ) {
                $o = wc_get_order($maybe_id);
                if ( $o ) return $o;
            }
            return null;
        }

        private function log($tag, $data) {
            if ( ! $this->logger ) return;
            $this->logger->info('[Payesv '.$tag.'] '. wp_json_encode($data), ['source' => 'payesv']);
        }
    }

    add_filter('woocommerce_payment_gateways', function ($gateways) {
        $gateways[] = 'WC_Gateway_Payesv';
        return $gateways;
    });
});

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links){
    $url = admin_url('admin.php?page=wc-settings&tab=checkout&section=payesv');
    $links[] = '<a href="' . esc_url($url) . '">' . __('Settings', 'payesv') . '</a>';
    return $links;
});
